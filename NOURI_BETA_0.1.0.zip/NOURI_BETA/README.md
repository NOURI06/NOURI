# NOURI BETA 0.1.0

A native Android Java prototype for NOURI.

## Included
- Native Android app (not a web app)
- Animated AICore orb
- Text chat with Gemini `generateContent`
- Speech input through Android SpeechRecognizer
- Spoken replies through Android TextToSpeech (en-GB preference)
- Settings screen for the Gemini API key and model name
- API key encrypted locally with Android Keystore + AES/GCM
- GitHub Actions workflow to build a debug APK

## Build an APK with GitHub Actions
1. Create or open the `NOURI` repository on GitHub.
2. Upload the contents of this folder to the repository root (keep `.github`).
3. Open **Actions** → **Build NOURI Android Beta**.
4. Choose **Run workflow**.
5. When it finishes, open the run and download the `NOURI-BETA-0.1.0` artifact.
6. Extract the artifact and install `app-debug.apk` on your Android phone. If Android asks, allow installation from the browser/file manager you used.

## First launch
1. Open NOURI.
2. Open Settings (gear icon).
3. Add your Gemini API key and save.
4. Send a text message or tap the microphone.

Create/manage the API key through Google AI Studio. The app sends requests directly to Google's Gemini API over HTTPS. API usage may be subject to Google's limits or charges depending on the account and current terms.

## Beta limitations
- This is an early test build, not a production release.
- Voice input uses the Android speech recognition service and may require internet / a supported speech service.
- The app does not have an always-on wake word yet. Android restricts background microphone use; wake-word support needs a separate, battery-conscious foreground-service design and clear user controls.
- App launching, browser actions, smart-home integrations, persistent memory, and a backend proxy are not implemented in this first beta.
- The API key is encrypted on-device, but a client-side API key can still be extracted from a compromised device. For a public release, move Gemini requests behind a secure backend and add per-user authentication and rate limits.
