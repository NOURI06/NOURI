package com.nouri.assistant;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Locale;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
    private static final String PREFS = "nouri_secure_beta";
    private static final String KEY_ALIAS = "NOURI_BETA_AES_KEY";
    private static final String DEFAULT_MODEL = "gemini-3.8-flash";

    private LinearLayout root, messages;
    private ScrollView scroll;
    private EditText composer;
    private TextView status;
    private OrbView orb;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private boolean ttsReady = false, speakingEnabled = true, busy = false;
    private String model = DEFAULT_MODEL;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ArrayList<JSONObject> history = new ArrayList<>();

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(4, 8, 17));
        getWindow().setNavigationBarColor(Color.rgb(4, 8, 17));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        initTts();
        buildUi();
        if (getApiKey().isEmpty()) showSetupDialog();
        addMessage("NOURI", "Systems online. I'm ready when you are.", false);
    }

    private void initTts() {
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                ttsReady = true;
                tts.setLanguage(Locale.UK);
                tts.setSpeechRate(0.94f);
                tts.setPitch(0.88f);
            }
        });
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(12), dp(18), dp(12));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(5,10,22), Color.rgb(7,17,32), Color.rgb(3,7,16)}));
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = label("N O U R I", 18, Color.WHITE, true);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1));
        TextView beta = label("BETA 0.1", 10, Color.rgb(80,210,255), true);
        top.addView(beta);
        TextView settings = label("⚙", 25, Color.rgb(155,205,235), false);
        settings.setPadding(dp(16), 0, dp(4), 0);
        settings.setOnClickListener(v -> showSettings());
        top.addView(settings);
        root.addView(top);

        orb = new OrbView(this);
        LinearLayout.LayoutParams orbLp = new LinearLayout.LayoutParams(-1, dp(205));
        orbLp.topMargin = dp(3);
        root.addView(orb, orbLp);

        status = label("ONLINE  •  READY", 10, Color.rgb(83,208,239), true);
        status.setGravity(Gravity.CENTER);
        status.setLetterSpacing(0.15f);
        root.addView(status, new LinearLayout.LayoutParams(-1, dp(24)));

        TextView section = label("CONVERSATION", 10, Color.rgb(118,153,180), true);
        section.setPadding(dp(2), dp(8), 0, dp(7));
        root.addView(section);

        scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(messages);
        LinearLayout.LayoutParams chatLp = new LinearLayout.LayoutParams(-1, 0, 1);
        root.addView(scroll, chatLp);

        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setPadding(dp(8), dp(7), dp(7), dp(7));
        inputRow.setBackground(round(Color.rgb(13,27,44), 24, Color.rgb(30,65,91), 1));
        composer = new EditText(this);
        composer.setSingleLine(false);
        composer.setMaxLines(3);
        composer.setTextColor(Color.WHITE);
        composer.setHintTextColor(Color.rgb(111,143,164));
        composer.setHint("Ask NOURI anything...");
        composer.setTextSize(14);
        composer.setPadding(dp(9), dp(7), dp(5), dp(7));
        composer.setBackgroundColor(Color.TRANSPARENT);
        inputRow.addView(composer, new LinearLayout.LayoutParams(0, -2, 1));
        TextView mic = actionButton("🎙");
        mic.setOnClickListener(v -> startListening());
        inputRow.addView(mic);
        TextView send = actionButton("➤");
        send.setTextColor(Color.rgb(4,18,30));
        send.setBackground(round(Color.rgb(65,204,245), 30, Color.TRANSPARENT, 0));
        send.setOnClickListener(v -> sendMessage());
        LinearLayout.LayoutParams sendLp = new LinearLayout.LayoutParams(dp(42), dp(42));
        sendLp.leftMargin = dp(6);
        inputRow.addView(send, sendLp);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(-1, -2);
        inputLp.topMargin = dp(10);
        root.addView(inputRow, inputLp);

        TextView foot = label("VOICE-FIRST INTELLIGENCE  •  BUILT TO EVOLVE", 8, Color.rgb(74,104,127), true);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(10), 0, dp(2));
        root.addView(foot);
    }

    private void sendMessage() {
        String prompt = composer.getText().toString().trim();
        if (prompt.isEmpty() || busy) return;
        composer.setText("");
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(composer.getWindowToken(), 0);
        addMessage("YOU", prompt, true);
        history.add(content("user", prompt));
        if (history.size() > 24) history.remove(0);
        askGemini();
    }

    private JSONObject content(String role, String text) {
        JSONObject item = new JSONObject();
        try {
            item.put("role", role);
            JSONArray parts = new JSONArray();
            parts.put(new JSONObject().put("text", text));
            item.put("parts", parts);
        } catch (Exception ignored) {}
        return item;
    }

    private void askGemini() {
        String apiKey = getApiKey();
        if (apiKey.isEmpty()) {
            addMessage("NOURI", "I need your Gemini API key first. Open Settings to add it.", false);
            showSettings();
            return;
        }
        busy = true;
        status.setText("THINKING  •  CONNECTING TO GEMINI");
        orb.setMode(1);
        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" +
                        model + ":generateContent");
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(60000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                connection.setRequestProperty("x-goog-api-key", apiKey);

                JSONObject body = new JSONObject();
                JSONArray contents = new JSONArray();
                for (JSONObject item : history) contents.put(item);
                body.put("contents", contents);
                body.put("systemInstruction", new JSONObject().put("parts",
                        new JSONArray().put(new JSONObject().put("text",
                        "You are NOURI, a helpful, calm, capable personal AI assistant. " +
                        "Speak naturally and concisely. The user prefers a polished British-style assistant tone. " +
                        "Be honest about limitations. Never claim to control the phone unless an Android action actually happens."))));
                body.put("generationConfig", new JSONObject().put("temperature", 0.7).put("maxOutputTokens", 900));

                try (OutputStream out = connection.getOutputStream()) {
                    out.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                int code = connection.getResponseCode();
                InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
                String response = readAll(stream);
                if (code < 200 || code >= 300) throw new Exception("Gemini API " + code + ": " + shortError(response));
                JSONObject json = new JSONObject(response);
                String answer = json.getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0).optString("text", "");
                if (answer.trim().isEmpty()) throw new Exception("Gemini returned an empty response.");
                history.add(content("model", answer));
                runOnUiThread(() -> {
                    addMessage("NOURI", answer, false);
                    if (speakingEnabled) speak(answer);
                    busy = false;
                    status.setText("ONLINE  •  READY");
                    orb.setMode(0);
                });
            } catch (Exception e) {
                String error = e.getMessage() == null ? "Connection failed." : e.getMessage();
                runOnUiThread(() -> {
                    addMessage("SYSTEM", error, false);
                    busy = false;
                    status.setText("ONLINE  •  CHECK CONNECTION / SETTINGS");
                    orb.setMode(0);
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096]; int n;
        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        return out.toString("UTF-8");
    }
    private String shortError(String raw) {
        try { return new JSONObject(raw).getJSONObject("error").optString("message", "Request failed"); }
        catch (Exception e) { return raw.length() > 180 ? raw.substring(0,180) : raw; }
    }

    private void addMessage(String who, String text, boolean user) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(13), dp(10), dp(13), dp(10));
        card.setBackground(round(user ? Color.rgb(14,43,62) : Color.rgb(10,22,37),
                15, user ? Color.rgb(32,104,133) : Color.rgb(25,58,81), 1));
        TextView heading = label(who, 9, user ? Color.rgb(94,208,246) : Color.rgb(89,180,213), true);
        TextView body = label(text, 14, Color.rgb(221,235,244), false);
        body.setLineSpacing(dp(3), 1f);
        body.setPadding(0, dp(5), 0, 0);
        card.addView(heading); card.addView(body);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(8);
        messages.addView(card, lp);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addMessage("SYSTEM", "Speech recognition isn't available on this phone.", false); return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 41); return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { status.setText("LISTENING  •  SPEAK NOW"); orb.setMode(2); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float rms) { orb.setLevel(rms); }
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() { status.setText("PROCESSING VOICE"); }
            public void onError(int e) {
                status.setText("ONLINE  •  READY"); orb.setMode(0);
                if (e != SpeechRecognizer.ERROR_NO_MATCH && e != SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                    addMessage("SYSTEM", "I couldn't hear that clearly. Please try again.", false);
            }
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                status.setText("ONLINE  •  READY"); orb.setMode(0);
                if (matches != null && !matches.isEmpty()) { composer.setText(matches.get(0)); sendMessage(); }
            }
            public void onPartialResults(Bundle p) {}
            public void onEvent(int t, Bundle p) {}
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-GB");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        recognizer.startListening(intent);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 41 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening();
    }

    private void speak(String text) {
        if (ttsReady && tts != null) {
            tts.setLanguage(Locale.UK);
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "NOURI_REPLY");
        }
    }

    private void showSetupDialog() {
        new AlertDialog.Builder(this).setTitle("Welcome to NOURI")
                .setMessage("Add your Gemini API key in Settings to activate the AI brain. Your key is stored encrypted on this device.")
                .setPositiveButton("OPEN SETTINGS", (d,w) -> showSettings())
                .setNegativeButton("LATER", null).show();
    }

    private void showSettings() {
        LinearLayout panel = new LinearLayout(this);
        panel.setPadding(dp(18), dp(8), dp(18), dp(4));
        panel.setOrientation(LinearLayout.VERTICAL);
        EditText keyInput = new EditText(this);
        keyInput.setSingleLine(true);
        keyInput.setHint("Gemini API key");
        keyInput.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        keyInput.setText(getApiKey());
        panel.addView(keyInput);
        EditText modelInput = new EditText(this);
        modelInput.setSingleLine(true);
        modelInput.setHint("Model name");
        modelInput.setText(model);
        panel.addView(modelInput);
        CheckBox voice = new CheckBox(this);
        voice.setText("Speak AI responses aloud");
        voice.setTextColor(Color.WHITE);
        voice.setButtonTintList(android.content.res.ColorStateList.valueOf(Color.rgb(65,204,245)));
        voice.setChecked(speakingEnabled);
        panel.addView(voice);
        new AlertDialog.Builder(this).setTitle("NOURI SETTINGS").setView(panel)
                .setPositiveButton("SAVE", (d,w) -> {
                    String key = keyInput.getText().toString().trim();
                    model = modelInput.getText().toString().trim();
                    if (model.isEmpty()) model = DEFAULT_MODEL;
                    speakingEnabled = voice.isChecked();
                    try {
                        if (!key.isEmpty()) saveApiKey(key);
                        Toast.makeText(this, "Settings saved on this device.", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(this, "Couldn't securely save the API key.", Toast.LENGTH_LONG).show();
                    }
                }).setNegativeButton("CANCEL", null).show();
    }

    private String getApiKey() {
        try {
            String packed = getSharedPreferences(PREFS, MODE_PRIVATE).getString("key", "");
            if (packed.isEmpty()) return "";
            String[] parts = packed.split(":", 2);
            byte[] iv = android.util.Base64.decode(parts[0], android.util.Base64.NO_WRAP);
            byte[] cipherText = android.util.Base64.decode(parts[1], android.util.Base64.NO_WRAP);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(cipherText), StandardCharsets.UTF_8);
        } catch (Exception e) { return ""; }
    }

    private void saveApiKey(String value) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getSecretKey());
        byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        String packed = android.util.Base64.encodeToString(cipher.getIV(), android.util.Base64.NO_WRAP) + ":" +
                android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("key", packed).apply();
    }

    private SecretKey getSecretKey() throws Exception {
        java.security.KeyStore ks = java.security.KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) return (SecretKey) ks.getKey(KEY_ALIAS, null);
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build());
        return generator.generateKey();
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size);
        t.setTextColor(color); t.setTypeface(android.graphics.Typeface.DEFAULT, bold ? 1 : 0); return t;
    }
    private TextView actionButton(String value) {
        TextView t = label(value, 20, Color.rgb(117,209,240), true);
        t.setGravity(Gravity.CENTER); t.setBackground(round(Color.rgb(18,42,61), 30, Color.rgb(33,78,103), 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(42), dp(42));
        t.setLayoutParams(lp); return t;
    }
    private GradientDrawable round(int color, int radius, int stroke, int width) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if (width > 0) d.setStroke(dp(width), stroke); return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        executor.shutdownNow();
        super.onDestroy();
    }

    private class OrbView extends View {
        private final Paint p = new Paint(3);
        private final HandlerTick tick = new HandlerTick();
        private int mode = 0; private float level = 0;
        private final long start = System.currentTimeMillis();
        OrbView(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); tick.run(); }
        void setMode(int m) { mode = m; invalidate(); }
        void setLevel(float l) { level = Math.max(0, Math.min(12, l)); invalidate(); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float cx = getWidth()/2f, cy = getHeight()/2f;
            float t = (System.currentTimeMillis()-start)/1000f;
            float pulse = (float)Math.sin(t*1.7f)*4f + (mode==1?7:0) + level*0.7f;
            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(cx,cy,dp(92), new int[]{0x5546D8FF,0x2231A9E8,0x0031A9E8}, null, Shader.TileMode.CLAMP));
            c.drawCircle(cx,cy,dp(88)+pulse,p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.2f));
            p.setColor(0x6657D7FF); c.drawCircle(cx,cy,dp(69)+pulse*.35f,p);
            p.setStrokeWidth(dp(1)); p.setColor(0x4438BCEB); c.drawCircle(cx,cy,dp(81),p);
            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(cx-dp(14),cy-dp(17),dp(58),
                    new int[]{0xFFB8F4FF,0xFF42BDEB,0xFF0875B7,0xFF061B39},
                    new float[]{0f,.25f,.68f,1f}, Shader.TileMode.CLAMP));
            c.drawCircle(cx,cy,dp(48)+pulse*.22f,p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(0xAA9BEFFF);
            RectF ring = new RectF(cx-dp(59),cy-dp(59),cx+dp(59),cy+dp(59));
            c.drawArc(ring, (t*38)%360, 105, false,p);
            c.drawArc(ring, 180+(t* -24)%360, 58, false,p);
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); p.setTextSize(dp(10));
            p.setColor(Color.WHITE); c.drawText(mode==2?"LISTENING":mode==1?"THINKING":"N O U R I",cx,cy+dp(4),p);
            p.setTextSize(dp(8)); p.setColor(0xFF9BDCF2);
            c.drawText(mode==2?"VOICE INPUT ACTIVE":mode==1?"PROCESSING":"AI CORE",cx,cy+dp(19),p);
        }
        class HandlerTick implements Runnable {
            public void run() { invalidate(); postDelayed(this, 40); }
        }
    }
}
