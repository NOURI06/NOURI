# NOURI BETA 2.0 — Android

This is a standalone Android project. It does not overwrite the original Windows Java project.

## Included
- NOURI amber/gold artwork used as the main screen background and brand identity.
- Microphone input through Android SpeechRecognizer.
- Spoken answers through Android TextToSpeech (English UK voice if installed on the phone).
- Gemini text responses using the Gemini API.
- Voice on/off control.
- GitHub Actions workflow to build a debug APK.

## Important beta limitations
- This is an early functional beta, not the finished public product.
- The Gemini API key is entered at runtime and held in app memory only. It is not bundled in the APK or saved by this build. For a public release, move Gemini requests behind a secured backend; never ship a shared API key inside an app.
- Speech recognition may use Android's configured speech service and may require internet.
- Wake-word listening, app/device control, browsing, smart-home integrations, persistent conversation memory, and an always-running background assistant are not implemented yet.

## Build
Open this folder as an Android project in an Android build environment, or use the included GitHub Actions workflow after uploading the folder into your repository. The workflow creates a debug APK artifact.

Requirements: Android SDK 35, Gradle 8.9, JDK 17.
