package com.nouri.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private EditText promptBox, keyBox;
    private TextView response, status, voiceToggle;
    private ImageButton micButton;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private boolean speakAnswers = true;
    private boolean listening = false;
    private static final int MIC_PERMISSION = 41;
    private static final String GOLD = "#FFC15A";
    private static final String API_URL =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(5,3,2));
        getWindow().setNavigationBarColor(Color.rgb(5,3,2));
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                             WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildScreen();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.UK);
                tts.setSpeechRate(0.94f);
            }
        });
        if (SpeechRecognizer.isRecognitionAvailable(this))
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        showStatus("SYSTEM ONLINE  •  READY");
    }

    private void buildScreen() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5,3,2));

        ImageView artwork = new ImageView(this);
        int imageId = getResources().getIdentifier("nouri_core", "drawable", getPackageName());
        if (imageId != 0) artwork.setImageResource(imageId);
        artwork.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(artwork, new FrameLayout.LayoutParams(-1, -1));

        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{0x18000000,0x18000000,0x88000000,0xF2050302}));
        root.addView(shade, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(18), dp(20), dp(14));
        FrameLayout.LayoutParams pageLp = new FrameLayout.LayoutParams(-1,-1);
        root.addView(page, pageLp);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("N.O.U.R.I", 19, GOLD, true);
        brand.setLetterSpacing(0.22f);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        status = text("INITIALIZING", 10, 0xFFFFDDAA, true);
        status.setLetterSpacing(0.12f);
        top.addView(status);
        page.addView(top);

        Space spacer1 = new Space(this);
        page.addView(spacer1, new LinearLayout.LayoutParams(1,0,1.0f));

        TextView hello = text("How can I help, sir?", 21, Color.WHITE, true);
        hello.setGravity(Gravity.CENTER);
        page.addView(hello, new LinearLayout.LayoutParams(-1,-2));

        TextView subtitle = text("YOUR PERSONAL AI ASSISTANT", 10, 0xFFFFD49A, false);
        subtitle.setLetterSpacing(0.20f);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1,-2);
        subLp.topMargin = dp(7);
        page.addView(subtitle, subLp);

        Space spacer2 = new Space(this);
        page.addView(spacer2, new LinearLayout.LayoutParams(1,0,0.65f));

        LinearLayout resultCard = new LinearLayout(this);
        resultCard.setOrientation(LinearLayout.VERTICAL);
        resultCard.setPadding(dp(15),dp(13),dp(15),dp(13));
        resultCard.setBackground(round(0xB8090705, 18, 0x66FFB33B));
        TextView label = text("NOURI", 10, GOLD, true);
        label.setLetterSpacing(0.16f);
        resultCard.addView(label);
        response = text("I’m listening. Ask me anything.", 14, Color.WHITE, false);
        response.setTextIsSelectable(true);
        LinearLayout.LayoutParams responseLp = new LinearLayout.LayoutParams(-1,-2);
        responseLp.topMargin = dp(7);
        resultCard.addView(response,responseLp);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1,-2);
        cardLp.bottomMargin = dp(12);
        page.addView(resultCard,cardLp);

        keyBox = new EditText(this);
        keyBox.setSingleLine(true);
        keyBox.setTextColor(Color.WHITE);
        keyBox.setHintTextColor(0xFFB5A18B);
        keyBox.setHint("Gemini API key (kept only in memory)");
        keyBox.setTextSize(12);
        keyBox.setPadding(dp(14),0,dp(14),0);
        keyBox.setBackground(round(0xCC120D08,14,0x55D99742));
        page.addView(keyBox,new LinearLayout.LayoutParams(-1,dp(46)));

        promptBox = new EditText(this);
        promptBox.setTextColor(Color.WHITE);
        promptBox.setHintTextColor(0xFFB5A18B);
        promptBox.setHint("Talk to NOURI...");
        promptBox.setTextSize(15);
        promptBox.setPadding(dp(15),dp(10),dp(15),dp(10));
        promptBox.setBackground(round(0xE6100B07,16,0x88FFB33B));
        LinearLayout.LayoutParams promptLp = new LinearLayout.LayoutParams(-1,dp(54));
        promptLp.topMargin = dp(10);
        page.addView(promptBox,promptLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(-1,dp(58));
        actionsLp.topMargin = dp(8);
        page.addView(actions,actionsLp);

        micButton = new ImageButton(this);
        micButton.setImageResource(android.R.drawable.ic_btn_speak_now);
        micButton.setColorFilter(Color.BLACK);
        micButton.setBackground(round(0xFFFFB33B,50,0xFFFFD88B));
        actions.addView(micButton,new LinearLayout.LayoutParams(dp(52),dp(52)));
        micButton.setOnClickListener(v -> startListening());

        voiceToggle = text("VOICE ON",11,GOLD,true);
        voiceToggle.setGravity(Gravity.CENTER);
        voiceToggle.setBackground(round(0xCC120D08,30,0x88FFB33B));
        LinearLayout.LayoutParams toggleLp = new LinearLayout.LayoutParams(dp(92),dp(42));
        toggleLp.leftMargin = dp(9);
        actions.addView(voiceToggle,toggleLp);
        voiceToggle.setOnClickListener(v -> {
            speakAnswers = !speakAnswers;
            voiceToggle.setText(speakAnswers ? "VOICE ON" : "VOICE OFF");
            if (!speakAnswers && tts != null) tts.stop();
        });

        View gap = new View(this);
        actions.addView(gap,new LinearLayout.LayoutParams(0,1,1));

        Button send = new Button(this);
        send.setText("SEND  ➤");
        send.setTextColor(Color.BLACK);
        send.setTextSize(12);
        send.setAllCaps(false);
        send.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        send.setBackground(round(0xFFFFB33B,30,0xFFFFD88B));
        actions.addView(send,new LinearLayout.LayoutParams(dp(104),dp(48)));
        send.setOnClickListener(v -> sendPrompt());

        setContentView(root);
    }

    private void startListening() {
        if (recognizer == null) { showStatus("SPEECH RECOGNITION UNAVAILABLE"); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION);
            return;
        }
        if (listening) { recognizer.cancel(); listening=false; showStatus("READY"); return; }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.UK.toLanguageTag());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak to NOURI");
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b) { listening=true; showStatus("LISTENING..."); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float rms) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() { listening=false; showStatus("THINKING..."); }
            public void onError(int e) { listening=false; showStatus("VOICE INPUT READY"); }
            public void onResults(Bundle b) {
                listening=false;
                ArrayList<String> matches=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if(matches!=null && !matches.isEmpty()) { promptBox.setText(matches.get(0)); sendPrompt(); }
                else showStatus("READY");
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int t,Bundle b) {}
        });
        recognizer.startListening(intent);
    }

    private void sendPrompt() {
        String question=promptBox.getText().toString().trim();
        String key=keyBox.getText().toString().trim();
        if(question.isEmpty()) { showStatus("TYPE OR SPEAK A QUESTION"); return; }
        if(key.isEmpty()) { showStatus("ADD YOUR GEMINI API KEY"); response.setText("Enter your Gemini API key above to connect NOURI."); return; }
        promptBox.setText("");
        response.setText("Thinking...");
        showStatus("CONNECTING TO GEMINI...");
        worker.execute(() -> {
            String answer;
            try { answer=askGemini(key,question); }
            catch(Exception ex) { answer="Connection error: "+ex.getMessage(); }
            final String finalAnswer=answer;
            runOnUiThread(() -> {
                response.setText(finalAnswer);
                showStatus(finalAnswer.startsWith("Connection error:") ? "CHECK CONNECTION / API KEY" : "ONLINE  •  READY");
                if(speakAnswers && tts!=null && !finalAnswer.startsWith("Connection error:"))
                    tts.speak(finalAnswer,TextToSpeech.QUEUE_FLUSH,null,"nouri-answer");
            });
        });
    }

    private String askGemini(String key,String prompt) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(API_URL+java.net.URLEncoder.encode(key,"UTF-8")).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type","application/json; charset=UTF-8");
        JSONObject part=new JSONObject().put("text","You are NOURI, a helpful, concise, polite personal AI assistant. Address the user respectfully when natural. User says: "+prompt);
        JSONObject body=new JSONObject().put("contents",new JSONArray().put(new JSONObject().put("parts",new JSONArray().put(part))));
        try(OutputStream out=c.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}
        int code=c.getResponseCode();
        InputStream stream=(code>=200 && code<300)?c.getInputStream():c.getErrorStream();
        ByteArrayOutputStream buffer=new ByteArrayOutputStream();
        byte[] data=new byte[4096]; int n;
        while((n=stream.read(data))!=-1) buffer.write(data,0,n);
        String raw=buffer.toString("UTF-8");
        c.disconnect();
        if(code<200 || code>=300) {
            try { return "Connection error: Gemini returned HTTP "+code+". "+new JSONObject(raw).optJSONObject("error").optString("message","Check the API key and model access."); }
            catch(Exception ignored) { return "Connection error: Gemini returned HTTP "+code+". Check the API key."; }
        }
        JSONObject json=new JSONObject(raw);
        JSONArray candidates=json.optJSONArray("candidates");
        if(candidates==null || candidates.length()==0) return "Gemini returned an empty answer. Try again.";
        return candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).optString("text","No text response.");
    }

    private void showStatus(String s) { if(status!=null) status.setText(s); }
    private TextView text(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    private GradientDrawable round(int color,int radius,int stroke) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        d.setStroke(dp(1),stroke); return d;
    }
    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if(requestCode==MIC_PERMISSION && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) startListening();
        else showStatus("MICROPHONE PERMISSION NEEDED");
    }
    @Override protected void onDestroy() {
        if(recognizer!=null) { recognizer.cancel(); recognizer.destroy(); }
        if(tts!=null) { tts.stop(); tts.shutdown(); }
        worker.shutdownNow();
        super.onDestroy();
    }
}
